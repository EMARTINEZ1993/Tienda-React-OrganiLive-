import React, { useState } from 'react';
import { sendContactMessage } from '../utils/googleSheetsService';

const ContactForm = () => {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((p) => ({ ...p, [name]: value }));
  };

  const validateForm = () => {
    const { name, email, message } = formData;
    if (!name.trim()) { alert('Por favor ingresa tu nombre'); return false; }
    if (!email.trim()) { alert('Por favor ingresa tu email'); return false; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { alert('Email inválido'); return false; }
    if (!message.trim()) { alert('Por favor ingresa tu mensaje'); return false; }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    setIsSubmitting(true);
    setSubmitStatus(null);
    try {
      const result = await sendContactMessage(formData);
      if (result.success) {
        setSubmitStatus({ type: 'success', message: '¡Mensaje enviado correctamente!' });
        setFormData({ name: '', email: '', phone: '', message: '' });
      } else {
        setSubmitStatus({ type: 'error', message: result.message || 'Error al enviar' });
      }
    } catch {
      setSubmitStatus({ type: 'error', message: 'Error al enviar mensaje' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const inputCls = 'w-full px-3 py-2 rounded-lg border border-green-200 bg-white text-green-900 placeholder-green-300 focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent text-xs transition-all';
  const labelCls = 'block text-xs font-semibold text-green-800 mb-1';

  return (
    <div className="bg-white rounded-xl shadow-sm border border-green-100 p-5">
      <div className="mb-4">
        <h2 className="text-base font-bold text-green-900">📧 Contáctanos</h2>
        <p className="text-green-500 text-xs mt-0.5">¿Tienes preguntas sobre nuestros productos? ¡Escríbenos!</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="name" className={labelCls}>Nombre *</label>
            <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} placeholder="Tu nombre" required className={inputCls} />
          </div>
          <div>
            <label htmlFor="email" className={labelCls}>Email *</label>
            <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} placeholder="tu@email.com" required className={inputCls} />
          </div>
        </div>

        <div>
          <label htmlFor="phone" className={labelCls}>Teléfono</label>
          <input type="tel" id="phone" name="phone" value={formData.phone} onChange={handleChange} placeholder="Tu teléfono" className={inputCls} />
        </div>

        <div>
          <label htmlFor="message" className={labelCls}>Mensaje *</label>
          <textarea id="message" name="message" value={formData.message} onChange={handleChange} placeholder="¿En qué podemos ayudarte?" rows={4} required className={`${inputCls} resize-none`} />
        </div>

        {submitStatus && (
          <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium ${
            submitStatus.type === 'success' ? 'bg-green-50 border border-green-200 text-green-700' : 'bg-red-50 border border-red-200 text-red-600'
          }`}>
            {submitStatus.type === 'success' ? '✅' : '❌'} {submitStatus.message}
          </div>
        )}

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-2 rounded-lg bg-green-600 hover:bg-green-500 text-white text-xs font-semibold shadow transition-all disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-1.5"
        >
          {isSubmitting ? (
            <><svg className="animate-spin w-3 h-3" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" /></svg> Enviando...</>
          ) : '📨 Enviar Mensaje'}
        </button>
      </form>
    </div>
  );
};

export default ContactForm;
