import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Header = () => {
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const getActive = () => {
    const p = location.pathname;
    if (p === '/' || p === '/inicio') return 'inicio';
    if (p === '/nosotros') return 'nosotros';
    if (p === '/registro') return 'registro';
    if (p === '/login') return 'login';
    return 'inicio';
  };

  const links = [
    { to: '/inicio', label: 'Inicio', key: 'inicio' },
    { to: '/nosotros', label: 'Nosotros', key: 'nosotros' },
    { to: '/registro', label: 'Registro', key: 'registro' },
    { to: '/login', label: 'Iniciar Sesión', key: 'login' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-green-900 shadow-md border-b border-green-700/40">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between h-11">
          <Link to="/inicio" className="flex items-center gap-1 group">
            <span className="text-base">🌱</span>
            <span className="text-sm font-bold text-white font-serif">
              Organi<span className="text-green-300">.Live</span>
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-0.5">
            {links.map(({ to, label, key }) => (
              <Link
                key={key}
                to={to}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                  getActive() === key
                    ? 'bg-green-500 text-white'
                    : 'text-green-200 hover:bg-green-700 hover:text-white'
                }`}
              >
                {label}
              </Link>
            ))}
          </nav>

          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden p-1 rounded text-green-200 hover:bg-green-700 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {menuOpen
                ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>
        </div>

        {menuOpen && (
          <div className="md:hidden pb-2 flex flex-col gap-0.5">
            {links.map(({ to, label, key }) => (
              <Link
                key={key}
                to={to}
                onClick={() => setMenuOpen(false)}
                className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                  getActive() === key ? 'bg-green-500 text-white' : 'text-green-200 hover:bg-green-700 hover:text-white'
                }`}
              >
                {label}
              </Link>
            ))}
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
